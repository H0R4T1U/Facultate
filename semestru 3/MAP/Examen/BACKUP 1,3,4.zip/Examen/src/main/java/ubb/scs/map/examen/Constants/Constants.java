package ubb.scs.map.examen.Constants;

public class Constants {
    public static final Float PRICE_PER_STATION = 10.0f;
}

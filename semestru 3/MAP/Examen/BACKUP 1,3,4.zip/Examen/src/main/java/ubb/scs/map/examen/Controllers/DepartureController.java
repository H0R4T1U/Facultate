package ubb.scs.map.examen.Controllers;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.scene.control.Alert;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ListView;
import ubb.scs.map.examen.domain.City;
import ubb.scs.map.examen.domain.TrainStations;

import java.util.List;

import static ubb.scs.map.examen.Constants.Constants.PRICE_PER_STATION;

public class DepartureController extends ControllerSuperclass {
    public ChoiceBox<City> ArivalField;
    public ChoiceBox<City> DepartureField;
    public CheckBox directField;
    public ListView<String> trainList;

    @Override
    public void init() {
        ArivalField.getItems().addAll(getService().getCities());
        DepartureField.getItems().addAll(getService().getCities());

    }

    public void Search(ActionEvent actionEvent) {
        Integer arivalId = ArivalField.getSelectionModel().getSelectedItem().getId();
        Integer departureId = DepartureField.getSelectionModel().getSelectedItem().getId();
        Boolean direct = directField.isSelected();
        ArivalField.getSelectionModel().clearSelection();
        DepartureField.getSelectionModel().clearSelection();
        if(arivalId != null && departureId != null && !departureId.equals(arivalId)) {
            List<List<TrainStations>> trains = getService().getTrainStations(departureId,arivalId,direct);
            initModel(trains);
        }else{
            showAlert("Warning","Datele introduse sunt incorecte!");

        }
    }
    private void initModel(List<List<TrainStations>> trains){
        ObservableList<String> observableData = FXCollections.observableArrayList();
        // pentru a nu avea duplicate orasele intermediare
        trains.forEach(list -> {
            int numberOfStations = list.size();
            String result = list.stream()
                    .map(trainStation -> {
                        StringBuilder sb = new StringBuilder();
                        sb.append(getService().getCityById(trainStation.getDepartureId()))
                                .append("-")
                                .append(trainStation.getId());

                        // Check if it's the last element
                        if (list.indexOf(trainStation) == list.size() - 1) {
                            sb.append("->")
                                    .append(getService().getCityById(trainStation.getArrivalId()));
                        }
                        sb.append(",price="+numberOfStations*PRICE_PER_STATION);
                        return sb.toString();
                    })
                    .reduce((a, b) -> a + "->" + b) // Join the elements with a space
                    .orElse(""); // Handle empty lists
            observableData.add(result.trim());
        });

        // Set the items in the ListView
        trainList.setItems(observableData);
    }
    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setContentText(message);
        alert.showAndWait();
    }
}


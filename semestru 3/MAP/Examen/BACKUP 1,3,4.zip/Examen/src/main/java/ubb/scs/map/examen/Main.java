package ubb.scs.map.examen;

public class Main {
    public static void main(String[] args) {
        HelloApplication.main(args);
    }
}

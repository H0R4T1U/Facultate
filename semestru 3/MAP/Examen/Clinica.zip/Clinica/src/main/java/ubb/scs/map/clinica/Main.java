package ubb.scs.map.clinica;

import ubb.scs.map.clinica.HelloApplication;

public class Main {
    public static void main(String[] args) {
        HelloApplication.main(args);

    }
}
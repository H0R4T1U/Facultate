package ubb.scs.map.clinica.Observers;


public interface Observer {
    void update();
}
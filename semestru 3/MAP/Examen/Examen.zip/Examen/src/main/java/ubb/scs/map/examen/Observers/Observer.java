package ubb.scs.map.examen.Observers;


public interface Observer {
    void update();
}
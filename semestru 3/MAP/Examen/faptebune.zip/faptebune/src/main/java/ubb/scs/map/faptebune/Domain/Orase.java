package ubb.scs.map.faptebune.Domain;

public enum Orase {
    BUCURESTI,
    CLUJ,
    ORADEA,
    CRAIOVA
}

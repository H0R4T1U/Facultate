package ubb.scs.map.avioane.Domain;

import java.util.List;

public class CompleteOrder {
    Order order;
    List<OrderItem> orderItem;
}

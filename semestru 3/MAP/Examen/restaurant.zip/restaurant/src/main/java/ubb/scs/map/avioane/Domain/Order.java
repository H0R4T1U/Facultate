package ubb.scs.map.avioane.Domain;

import java.time.LocalDateTime;
import java.util.List;

public class Order {
    private Integer id;
    private Integer table;
    private List<OrderItem> orderItems;
    private LocalDateTime date;
    private OrderStatus status;

    public Order(Integer table, LocalDateTime date, OrderStatus status) {
        this.table = table;
        this.date = date;
        this.status = status;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getTable() {
        return table;
    }

    public void setTable(Integer table) {
        this.table = table;
    }

    public List<OrderItem> getOrderItems() {
        return orderItems;
    }

    public void setOrderItems(List<OrderItem> orderItems) {
        this.orderItems = orderItems;
    }


    public LocalDateTime getDate() {
        return date;
    }

    public void setDate(LocalDateTime date) {
        this.date = date;
    }

    public OrderStatus getStatus() {
        return status;
    }

    public void setStatus(OrderStatus status) {
        this.status = status;
    }
}

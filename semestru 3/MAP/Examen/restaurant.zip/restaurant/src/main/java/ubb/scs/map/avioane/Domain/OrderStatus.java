package ubb.scs.map.avioane.Domain;

public enum OrderStatus {
    PLACED, PREPARING, SERVED
}
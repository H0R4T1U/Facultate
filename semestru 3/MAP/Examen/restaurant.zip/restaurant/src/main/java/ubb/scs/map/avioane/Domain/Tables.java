package ubb.scs.map.avioane.Domain;

public class Tables {
    public Tables() {
    }

    private int id;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}

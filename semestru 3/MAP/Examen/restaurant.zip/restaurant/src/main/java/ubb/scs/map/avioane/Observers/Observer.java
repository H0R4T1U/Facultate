package ubb.scs.map.avioane.Observers;


public interface Observer {
    void update();
}
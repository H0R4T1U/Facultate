namespace moto.networking.jsonprotocol;

public enum RequestType {
    LOGIN, LOGOUT,GET_RACES,GET_TEAM_PLAYERS,ADD_PLAYER,GET_TEAM
}

namespace moto.networking.jsonprotocol;

public enum ResponseType {
    OK, ERROR,UPDATE,GET_TEAM_PLAYERS,NEW_PLAYER,GET_RACES,GET_TEAM
}
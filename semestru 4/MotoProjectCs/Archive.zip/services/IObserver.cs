using moto.model;

namespace moto.services;

public interface IObserver
{

    void PlayerAdded(Player player);
}

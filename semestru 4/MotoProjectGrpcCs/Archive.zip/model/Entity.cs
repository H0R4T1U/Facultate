namespace moto.model;

public class Entity<ID>
{ 
    public ID Id { get; set; }
    
}
using moto.model;

namespace moto.persistence;

public interface IRaceRepository:IRepository<int,Race>
{
    
}
package testing.motorest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MotoRestApplication {

    public static void main(String[] args) {
        SpringApplication.run(MotoRestApplication.class, args);
    }

}

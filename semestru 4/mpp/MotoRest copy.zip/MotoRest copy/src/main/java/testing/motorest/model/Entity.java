package testing.motorest.model;

public interface Entity<ID>  {
    public ID getId();
    public void setId(ID id);

}
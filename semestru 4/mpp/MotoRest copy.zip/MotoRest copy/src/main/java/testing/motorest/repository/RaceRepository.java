package testing.motorest.repository;


import testing.motorest.model.Race;

public interface RaceRepository extends Repository<Integer, Race> {

}

package testing.motorest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MotoRestApplicationTests {

    @Test
    void contextLoads() {
    }

}
